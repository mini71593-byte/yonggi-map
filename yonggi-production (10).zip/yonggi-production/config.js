// Fill these from Supabase Project Settings > API. The anon/publishable key is safe for browsers ONLY with RLS enabled.
window.YONGGI_CONFIG = {
  supabaseUrl: 'REPLACE_WITH_SUPABASE_URL',
  supabaseAnonKey: 'REPLACE_WITH_SUPABASE_PUBLISHABLE_KEY'
};
