-- Run in Supabase SQL Editor. Do not expose service_role keys in the browser.
create extension if not exists pgcrypto;
create table public.admins (user_id uuid primary key references auth.users(id) on delete cascade);
create table public.submissions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 student_no text not null check (student_no ~ '^[0-9]{5}$'), student_name text not null check (char_length(student_name) between 1 and 30),
 phone text not null check (phone ~ '^01[0-9]-?[0-9]{3,4}-?[0-9]{4}$'),
 body text not null check (char_length(body) between 1 and 1000),
 status text not null default 'pending' check(status in ('pending','approved','rejected')),
 photo_paths text[] not null default '{}', created_at timestamptz not null default now()
);
create table public.site_settings (id int primary key default 1 check(id=1), video_url text not null default '', period text not null default '2026년 11월 9일(월) ~ 11월 13일(금)', prize1 text not null default '스타벅스 기프티콘 30,000원', prize2 text not null default '스타벅스 기프티콘 20,000원');
insert into public.site_settings(id) values(1);
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.admins where user_id=(select auth.uid())) $$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;
alter table public.admins enable row level security;
alter table public.submissions enable row level security;
alter table public.site_settings enable row level security;
create policy "admins read own membership" on public.admins for select to authenticated using(user_id=(select auth.uid()));
create policy "students see own or admin" on public.submissions for select to authenticated using(user_id=(select auth.uid()) or public.is_admin());
create policy "students submit pending" on public.submissions for insert to authenticated with check(user_id=(select auth.uid()) and status='pending' and cardinality(photo_paths) between 1 and 4 and (select bool_and(p like (select auth.uid())::text || '/%') from unnest(photo_paths) as p));
create policy "admin review" on public.submissions for update to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "settings public read" on public.site_settings for select to anon, authenticated using(true);
create policy "settings admin update" on public.site_settings for update to authenticated using(public.is_admin()) with check(public.is_admin());
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types) values ('proofs','proofs',false,5242880,array['image/jpeg','image/png','image/webp']) on conflict(id) do nothing;
create policy "owner uploads" on storage.objects for insert to authenticated with check(bucket_id='proofs' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy "owner and admin read" on storage.objects for select to authenticated using(bucket_id='proofs' and ((storage.foldername(name))[1]=(select auth.uid())::text or public.is_admin()));
-- AFTER the administrator signs up, promote that exact user ID manually in SQL editor:
-- insert into public.admins(user_id) values ('REPLACE_WITH_AUTH_USER_UUID');
-- Restrict review edits to status only, even for authenticated administrators.
revoke update on public.submissions from authenticated;
grant update(status) on public.submissions to authenticated;
