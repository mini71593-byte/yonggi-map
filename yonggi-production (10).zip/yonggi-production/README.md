# 용기내지도 — 서버 연결형 배포 프로젝트

이 버전은 Supabase를 연결하면 서로 다른 기기에서 학생 제출 및 운영자 승인이 공유되는 구조입니다. **현재는 배포/서버 설정이 완료되지 않았습니다.** `index.html`을 파일로 여는 것만으로는 작동하지 않습니다.

## 설치 순서
1. Supabase 프로젝트 생성 후 SQL Editor에서 `schema.sql` 실행. 오류 없이 완료됐는지 확인.
2. Supabase Authentication > Providers에서 이메일 인증 사용. 이메일 템플릿을 6자리 OTP (`{{ .Token }}`) 방식으로 설정. 운영 전에 이메일 발송 제한/SMTP 확인.
3. Project Settings > API에서 Project URL과 publishable/anon key를 `config.js`에 입력. **service_role/secret key를 넣지 말 것.**
4. Netlify Drop에 `index.html`, `app.js`, `stores.js`, `config.js`가 들어 있는 **폴더 전체**를 업로드 (ZIP을 쓰면 압축 해제 후 폴더 업로드). 또는 GitHub 저장소로 배포.
5. Supabase Authentication > URL Configuration에서 Site URL을 배포한 HTTPS 주소로 설정. 필요시 Redirect URLs 추가.
6. 운영자 이메일로 사이트에서 OTP 로그인 후 Supabase Authentication > Users에서 해당 계정 UUID 확인. SQL Editor에서 `insert into public.admins(user_id) values ('UUID');` 실행. 다시 로그인하면 운영자 메뉴가 보임.
7. 학생 계정/운영자 계정을 각각 다른 기기에서 테스트: 학생 제출 → 운영자 승인 → 학생 승인 표시.
8. 개인정보 수집 동의서의 운영 주체, 연락처, 보유·파기 기간, 보호자 동의 필요 여부를 학교 담당자와 확정하고 페이지에 반영한 후 공개.

## 중요 보안·운영 제한
- 관리자 권한은 HTML에서 숨기는 것만이 아니라 Supabase RLS 정책으로 제어됨. 학생은 자기 기록만 조회할 수 있음.
- 학생 이메일 OTP가 본인 계정을 구분하지만 **학번·이름의 진위까지 검증하지는 않음**. 학교 계정으로 이메일 도메인을 제한하려면 서버측 인증 훅/별도 인증 체계 필요.
- 제출 가능 기간(11월 9~13일) **서버 차단 로직은 아직 없음**. 현재 날짜는 화면 표시용이며, 실제 공개 전 서버측 제출 기간 제한이 필요.
- 이미지 파일은 비공개 버킷에 저장하고 로그인한 소유자 또는 관리자에게만 짧은 만료시간의 서명 URL로 제공됨.
- 운영자 메뉴가 학생에게 안 보이지만 URL 접근 제한은 RLS가 담당함.
- 지도는 Google Maps iframe이며 일부 환경에서 지도 표시가 차단될 수 있음. 33개 동시 마커 표시를 위해서는 카카오맵 JavaScript API 키, 도메인 등록 및 주소 좌표 변환이 추가로 필요함.
- 운영 전 학생 정보 및 결제 사진의 보관·삭제 정책, 파일 악성코드 검사, 업로드 횟수 제한, 관리자 감사 기록, 중복 인증 검증, 스팸 방지 등을 검토할 것.
- **학교 실제 행사에 즉시 사용 가능한 보안 심사 완료 제품은 아님.** 실데이터를 받기 전에 테스트와 운영자 확인이 필요함.
